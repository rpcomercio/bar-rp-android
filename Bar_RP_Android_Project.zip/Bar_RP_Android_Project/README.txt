BAR RP — PROJECTO ANDROID OFFLINE
================================

O que contém:
- Aplicação Android nativa (WebView) com interface local/offline.
- Cadastro de produtos, entradas de mercadoria, stock, vendas, despesas, painel de lucro estimado.
- Cópia de segurança e restauro em JSON.
- Moeda Kz.

IMPORTANTE:
Este é o código-fonte do projecto, NÃO é um APK já compilado nem testado.
Para gerar o APK:
1. Num computador, instale Android Studio actualizado.
2. Abra a pasta Bar_RP_Android_Project como projecto existente.
3. Permita ao Android Studio instalar o Android SDK / Gradle necessários.
4. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Instale o APK de debug no telemóvel Android e teste com dados de exemplo.
6. Exporte uma cópia de segurança regularmente.

Dados:
Os dados são guardados localmente no armazenamento WebView deste aparelho.
Limpar os dados da aplicação pode apagar os registos. Exporte backup antes.
A primeira versão não sincroniza dados entre aparelhos nem envia dados para a internet.

Stock:
O sistema calcula stock inicial + entradas de mercadoria - vendas. Registe todas as entradas pela secção Produtos/Stock.
